// =====================================================================
//  BalInput.cpp  -  hier staat hoe de library het werk doet.
//  (In BalInput.h staat WAT hij kan, hier staat HOE.)
// =====================================================================

#include "BalInput.h"

// ---------------------------------------------------------------------
// Instellingen voor het meten
// "static const" = alleen in dit bestand zichtbaar en verandert nooit.
// ---------------------------------------------------------------------
static const int AANTAL_METINGEN = 5;   // zoveel keer meten per ronde
static const int MIN_GELDIG = 3;        // minstens zoveel moeten een bal zien

// ---------------------------------------------------------------------
// MEDIAAN: sorteer de getallen en geef de middelste terug.
//
// Voorbeeld: 10, 12, 11, 90, 11  ->  gesorteerd: 10, 11, 11, 12, 90
//            De mediaan is 11. De foute meting 90 doet niet mee.
//
// Een gemiddelde zou hier 26,8 geven en dat klopt niet. Daarom gebruiken
// we de mediaan: die negeert uitschieters vanzelf.
//
// De sortering heet "bubble sort": steeds twee buren vergelijken en
// wisselen als de linker groter is. Na genoeg rondes staat alles goed.
// ---------------------------------------------------------------------
static int mediaan(int lijst[], int aantal) {
  for (int i = 0; i < aantal - 1; i++) {
    for (int j = 0; j < aantal - 1 - i; j++) {
      if (lijst[j] > lijst[j + 1]) {
        int tijdelijk = lijst[j];       // even bewaren...
        lijst[j] = lijst[j + 1];        // ...zodat we kunnen wisselen
        lijst[j + 1] = tijdelijk;
      }
    }
  }
  return lijst[aantal / 2];   // de middelste plek (bij 5 getallen: plek 2)
}

// ---------------------------------------------------------------------
// OMREKENEN van een ruwe waarde naar millimeters vanaf het midden.
//
// Stap 1: bereken hoe ver de waarde tussen min en max zit (0 tot 1).
// Stap 2: maak daar -1 tot +1 van en vermenigvuldig met de halve
//         afmeting. Resultaat: -half ... 0 ... +half
//
// Voorbeeld: min=200, max=3800, half=85 mm, ruw=2000 (precies het midden)
//   deel = (2000-200)/(3800-200) = 0,5  ->  (0,5*2-1)*85 = 0 mm
// ---------------------------------------------------------------------
static float naarMm(int ruw, int ruwMin, int ruwMax, float halfGrootte) {
  if (ruwMax == ruwMin) {
    return 0;   // kalibratie niet ingevuld: delen door nul voorkomen
  }
  float deel = (float)(ruw - ruwMin) / (float)(ruwMax - ruwMin);
  return (deel * 2.0 - 1.0) * halfGrootte;
}

// ---------------------------------------------------------------------
// begin(): start de module via I2C
// ---------------------------------------------------------------------
bool BalInput::begin() {
  return _touch.begin();   // standaard adres 0x48
}

// ---------------------------------------------------------------------
// kalibreer(): bewaar de kalibratiewaarden in de library
// ---------------------------------------------------------------------
void BalInput::kalibreer(int rawMinX, int rawMaxX, int rawMinY, int rawMaxY,
                         float halfBreedte, float halfHoogte) {
  _rawMinX = rawMinX;
  _rawMaxX = rawMaxX;
  _rawMinY = rawMinY;
  _rawMaxY = rawMaxY;
  _halfBreedte = halfBreedte;
  _halfHoogte = halfHoogte;
}

void BalInput::zetMinDruk(int minDruk) {
  _minDruk = minDruk;
}

// ---------------------------------------------------------------------
// lees(): meet 5 keer en geef de positie in mm terug
// ---------------------------------------------------------------------
BalPositie BalInput::lees() {
  // Begin met het antwoord "geen bal". Pas als alles goed gaat veranderen
  // we dat naar "wel een bal".
  BalPositie antwoord;
  antwoord.aanwezig = false;
  antwoord.x = 0;
  antwoord.y = 0;

  int lijstX[AANTAL_METINGEN];   // hier bewaren we de geldige metingen
  int lijstY[AANTAL_METINGEN];
  int geldig = 0;                // hoeveel geldige metingen we al hebben

  for (int n = 0; n < AANTAL_METINGEN; n++) {
    uint16_t x, y, z1, z2;       // de module geeft 4 getallen terug

    // read_touch() geeft true als de module iets voelt, en vult dan:
    //   x en y  = positie (0 tot 4095)
    //   z1, z2  = maat voor de druk (z1 wordt groter bij harder drukken)
    bool aangeraakt = _touch.read_touch(&x, &y, &z1, &z2);

    // Alleen tellen als er echt iets op ligt EN er hard genoeg gedrukt is.
    if (aangeraakt && z1 >= _minDruk) {
      lijstX[geldig] = x;
      lijstY[geldig] = y;
      geldig++;
    }
  }

  // Te weinig geldige metingen? Dan ligt er geen bal op.
  if (geldig < MIN_GELDIG) {
    return antwoord;
  }

  // Mediaan van de geldige metingen, per as.
  int ruwX = mediaan(lijstX, geldig);
  int ruwY = mediaan(lijstY, geldig);

  // Omrekenen naar mm en het antwoord invullen.
  antwoord.x = naarMm(ruwX, _rawMinX, _rawMaxX, _halfBreedte);
  antwoord.y = naarMm(ruwY, _rawMinY, _rawMaxY, _halfHoogte);
  antwoord.aanwezig = true;
  return antwoord;
}
