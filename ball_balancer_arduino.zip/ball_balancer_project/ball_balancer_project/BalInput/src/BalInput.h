// =====================================================================
//  BalInput  -  de "ogen" van de ball balancer
//
//  Deze library regelt ALLES rond het touchscreen:
//    - de module (TSC2007) opstarten
//    - 5 keer meten per ronde
//    - de middelste waarde nemen (mediaan) tegen uitschieters
//    - de ruwe getallen omrekenen naar millimeters vanaf het midden
//
//  Jij hoeft in je hoofdprogramma alleen te vragen: "waar ligt de bal?"
//
//  Gebruik:
//      BalInput invoer;
//      invoer.begin();
//      BalPositie bal = invoer.lees();
//      if (bal.aanwezig) { ... bal.x en bal.y in mm ... }
// =====================================================================

// Dit stukje (#ifndef ... #endif) heet een "include guard". Het zorgt dat
// de computer dit bestand maar EEN keer inleest, ook al staat het er
// per ongeluk twee keer in. Gewoon laten staan.
#ifndef BALINPUT_H
#define BALINPUT_H

#include <Arduino.h>
#include <Adafruit_TSC2007.h>   // de bibliotheek van Adafruit voor jouw module

// ---------------------------------------------------------------------
// Een "doosje" met het antwoord van de touchscreen. Zo kan lees()
// drie dingen tegelijk teruggeven.
// ---------------------------------------------------------------------
struct BalPositie {
  bool aanwezig;   // true = er ligt een bal op, false = geen bal
  float x;         // afstand tot het midden in mm (links is negatief)
  float y;         // afstand tot het midden in mm
};

// ---------------------------------------------------------------------
// De library zelf. Een "class" is een bouwtekening: je maakt er een
// echt object van met  BalInput invoer;
// ---------------------------------------------------------------------
class BalInput {
 public:
  // Start de module. Geeft false terug als de module niet gevonden wordt
  // (bijvoorbeeld door een losse draad).
  bool begin();

  // Vertel de library hoe jouw paneel de randen meet:
  //   rawMinX, rawMaxX = ruwe waarden (0-4095) links en rechts
  //   rawMinY, rawMaxY = ruwe waarden onderaan en bovenaan
  //   halfBreedte, halfHoogte = de helft van de afmetingen in mm
  // Zet je min en max omgekeerd, dan draait de richting om.
  void kalibreer(int rawMinX, int rawMaxX, int rawMinY, int rawMaxY,
                 float halfBreedte, float halfHoogte);

  // Hoe hard moet er gedrukt worden voor het telt als "bal erop"?
  void zetMinDruk(int minDruk);

  // Meet en geef de positie van de bal terug.
  BalPositie lees();

 private:
  // "private" = alleen deze library gebruikt dit, het hoofdprogramma niet.
  Adafruit_TSC2007 _touch;   // het object van de Adafruit-bibliotheek

  // Beginwaarden. Die worden overschreven door kalibreer().
  int _rawMinX = 200;
  int _rawMaxX = 3900;
  int _rawMinY = 200;
  int _rawMaxY = 3900;
  float _halfBreedte = 85;
  float _halfHoogte = 64;
  int _minDruk = 100;
};

#endif
