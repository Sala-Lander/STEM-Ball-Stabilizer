// =====================================================================
//  BalOutput.cpp  -  hier staat hoe de library de servo's aanstuurt.
// =====================================================================

#include "BalOutput.h"

// ---------------------------------------------------------------------
// begin(): servo's koppelen aan hun pinnen en platform vlak zetten
// ---------------------------------------------------------------------
void BalOutput::begin(int pinX, int pinY) {
  _servoX.attach(pinX);   // "attach" = koppel de servo aan deze pin
  _servoY.attach(pinY);
  vlak();
}

// ---------------------------------------------------------------------
// zetUitslag(): de belangrijkste functie.
//
// Stappen:
//  1. Begrens de uitslag, zodat het platform nooit te ver kantelt.
//  2. Draai het teken om als de servo gespiegeld gemonteerd zit.
//  3. Tel de uitslag op bij het midden (90) en rond af op hele graden.
//  4. Zorg dat de hoek tussen 0 en 180 blijft (meer kan een servo niet).
//  5. Stuur de servo aan.
//
// Voorbeeld met middenX = 90 en omkeerX = true:
//   zetUitslag(6, 0)  ->  6 wordt -6  ->  90 + (-6) = 84 graden
// ---------------------------------------------------------------------
void BalOutput::zetUitslag(float uitslagX, float uitslagY) {
  // 1. Begrenzen. constrain(x, laag, hoog) houdt x tussen laag en hoog.
  uitslagX = constrain(uitslagX, -_maxUitslag, _maxUitslag);
  uitslagY = constrain(uitslagY, -_maxUitslag, _maxUitslag);

  // 2. Richting omdraaien indien nodig.
  if (_omkeerX) {
    uitslagX = -uitslagX;
  }
  if (_omkeerY) {
    uitslagY = -uitslagY;
  }

  // 3 en 4. Midden erbij optellen, afronden en tussen 0 en 180 houden.
  int hoekX = constrain((int)round(_middenX + uitslagX), 0, 180);
  int hoekY = constrain((int)round(_middenY + uitslagY), 0, 180);

  // 5. Aansturen. write() neemt een hoek in graden.
  _servoX.write(hoekX);
  _servoY.write(hoekY);
}

// ---------------------------------------------------------------------
// vlak(): beide servo's naar hun midden
// ---------------------------------------------------------------------
void BalOutput::vlak() {
  zetUitslag(0, 0);
}

// ---------------------------------------------------------------------
// Kleine instellingen
// ---------------------------------------------------------------------
void BalOutput::zetMidden(int middenX, int middenY) {
  _middenX = middenX;
  _middenY = middenY;
}

void BalOutput::zetMaxUitslag(float graden) {
  _maxUitslag = graden;
}

void BalOutput::keerOm(bool omkeerX, bool omkeerY) {
  _omkeerX = omkeerX;
  _omkeerY = omkeerY;
}
