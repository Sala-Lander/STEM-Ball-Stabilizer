// =====================================================================
//  BalOutput  -  de "spieren" van de ball balancer
//
//  Deze library regelt ALLES rond de 2 servo's:
//    - de servo's aansluiten op hun pinnen
//    - het midden (90 graden = platform vlak)
//    - de maximale uitslag (zodat het platform nooit te ver kantelt)
//    - de richting van elke servo (omkeren als hij gespiegeld zit)
//
//  Jij geeft alleen: "servo X moet 5 graden uitslaan, servo Y -3 graden"
//  en de library zet de servo's op de juiste hoek.
//
//  "Uitslag" = hoeveel graden de servo van zijn midden af mag draaien.
//  Positief en negatief zijn de twee kanten op.
//
//  Gebruik:
//      BalOutput uitvoer;
//      uitvoer.begin(11, 10);
//      uitvoer.zetUitslag(5, -3);
//      uitvoer.vlak();
// =====================================================================

#ifndef BALOUTPUT_H
#define BALOUTPUT_H

#include <Arduino.h>
#include <Servo.h>

class BalOutput {
 public:
  // Koppel de servo's aan hun pinnen en zet het platform vlak.
  void begin(int pinX, int pinY);

  // Zet de servo's op een uitslag (in graden vanaf het midden).
  void zetUitslag(float uitslagX, float uitslagY);

  // Platform vlak (beide servo's op hun midden).
  void vlak();

  // Instellingen (allemaal optioneel):
  void zetMidden(int middenX, int middenY);   // fijn afstellen van "vlak"
  void zetMaxUitslag(float graden);           // grens in graden
  void keerOm(bool omkeerX, bool omkeerY);    // richting omdraaien

 private:
  Servo _servoX;   // de servo van de X-as
  Servo _servoY;   // de servo van de Y-as

  int _middenX = 90;         // 90 graden is het midden van een servo
  int _middenY = 90;
  float _maxUitslag = 40;    // maximaal 40 graden van het midden af
  bool _omkeerX = true;      // zelfde als de maker: X-servo gespiegeld
  bool _omkeerY = false;
};

#endif
