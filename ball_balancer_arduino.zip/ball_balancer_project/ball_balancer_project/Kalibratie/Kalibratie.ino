// =====================================================================
//  KALIBRATIE - meet de ruwe waarden van jouw touchscreen
//
//  Zo gebruik je dit:
//   1. Upload deze sketch en open de Serial Monitor (115200 baud).
//   2. Druk (met een vinger of de bal) langs ALLE vier de randen van het
//      actieve oppervlak, en ook in het midden.
//   3. Lees onderaan de regel "minX / maxX / minY / maxY" af.
//   4. Vul die getallen in bij RAW_MIN_X, RAW_MAX_X, enz. in BallBalancer.
//
//  Ook handig: "druk" laat zien hoe hard de bal drukt. Rol of leg de bal
//  neer en kijk welke waarde hij haalt. Zet MIN_DRUK in BallBalancer
//  ruim onder die waarde, maar boven de waarde bij "geen aanraking".
// =====================================================================

#include <Adafruit_TSC2007.h>

Adafruit_TSC2007 touch;

// We onthouden de kleinste en grootste waarden die we ooit zagen.
int minX = 4095;
int maxX = 0;
int minY = 4095;
int maxY = 0;

void setup() {
  Serial.begin(115200);

  if (!touch.begin()) {
    Serial.println("Touchscreen-module niet gevonden!");
    Serial.println("Controleer: SDA naar A4, SCL naar A5, voeding en GND.");
    while (true) {
    }
  }
  Serial.println("Module gevonden! Druk nu langs alle randen van het paneel.");
}

void loop() {
  uint16_t x, y, z1, z2;

  // true = er is iets aangeraakt
  if (touch.read_touch(&x, &y, &z1, &z2)) {
    // Onthoud de uiterste waarden.
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;

    Serial.print("x=");     Serial.print(x);
    Serial.print(" y=");    Serial.print(y);
    Serial.print(" druk="); Serial.print(z1);
    Serial.print(" | minX="); Serial.print(minX);
    Serial.print(" maxX=");   Serial.print(maxX);
    Serial.print(" minY=");   Serial.print(minY);
    Serial.print(" maxY=");   Serial.println(maxY);
  }
  else {
    Serial.println("geen aanraking");
  }

  delay(100);   // 10 keer per seconde is genoeg om te lezen
}
