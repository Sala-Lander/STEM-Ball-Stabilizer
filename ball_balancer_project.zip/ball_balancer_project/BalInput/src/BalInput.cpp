#include "BalInput.h"

static const int AANTAL_METINGEN = 5;
static const int MIN_GELDIG = 3;

static int mediaan(int lijst[], int aantal) {
  for (int i = 0; i < aantal - 1; i++) {
    for (int j = 0; j < aantal - 1 - i; j++) {
      if (lijst[j] > lijst[j + 1]) {
        int tijdelijk = lijst[j];
        lijst[j] = lijst[j + 1];
        lijst[j + 1] = tijdelijk;
      }
    }
  }

  return lijst[aantal / 2];
}

static float naarMm(int ruw, int ruwMin, int ruwMax, float halfGrootte) {
  if (ruwMax == ruwMin) {
    return 0;
  }

  float deel = (float)(ruw - ruwMin) / (float)(ruwMax - ruwMin);
  return (deel * 2.0 - 1.0) * halfGrootte;
}

bool BalInput::begin() {
  maakPinnenVrij();
  return true;
}

void BalInput::kalibreer(int rawMinX, int rawMaxX, int rawMinY, int rawMaxY,
                         float halfBreedte, float halfHoogte) {
  _rawMinX = rawMinX;
  _rawMaxX = rawMaxX;
  _rawMinY = rawMinY;
  _rawMaxY = rawMaxY;
  _halfBreedte = halfBreedte;
  _halfHoogte = halfHoogte;
}

void BalInput::zetMinDruk(int minDruk) {
  _minDruk = minDruk;
}

void BalInput::maakPinnenVrij() {
  pinMode(PIN_X_PLUS, INPUT);
  pinMode(PIN_X_MIN, INPUT);
  pinMode(PIN_Y_PLUS, INPUT);
  pinMode(PIN_Y_MIN, INPUT);
}

bool BalInput::isAangeraakt() {
  pinMode(PIN_X_PLUS, OUTPUT);
  digitalWrite(PIN_X_PLUS, LOW);

  pinMode(PIN_X_MIN, INPUT);
  pinMode(PIN_Y_PLUS, INPUT_PULLUP);
  pinMode(PIN_Y_MIN, INPUT);

  delayMicroseconds(20);
  bool aangeraakt = (digitalRead(PIN_Y_PLUS) == LOW);

  maakPinnenVrij();
  return aangeraakt;
}

int BalInput::leesRuweX() {
  pinMode(PIN_X_PLUS, OUTPUT);
  digitalWrite(PIN_X_PLUS, HIGH);

  pinMode(PIN_X_MIN, OUTPUT);
  digitalWrite(PIN_X_MIN, LOW);

  pinMode(PIN_Y_PLUS, INPUT);
  pinMode(PIN_Y_MIN, INPUT);

  delayMicroseconds(20);
  int waarde = analogRead(PIN_Y_PLUS);

  maakPinnenVrij();

  return waarde * 4;
}

int BalInput::leesRuweY() {
  pinMode(PIN_Y_PLUS, OUTPUT);
  digitalWrite(PIN_Y_PLUS, HIGH);

  pinMode(PIN_Y_MIN, OUTPUT);
  digitalWrite(PIN_Y_MIN, LOW);

  pinMode(PIN_X_PLUS, INPUT);
  pinMode(PIN_X_MIN, INPUT);

  delayMicroseconds(20);
  int waarde = analogRead(PIN_X_PLUS);

  maakPinnenVrij();

  return waarde * 4;
}

BalPositie BalInput::lees() {
  BalPositie antwoord;
  antwoord.aanwezig = false;
  antwoord.x = 0;
  antwoord.y = 0;

  int lijstX[AANTAL_METINGEN];
  int lijstY[AANTAL_METINGEN];
  int geldig = 0;

  for (int n = 0; n < AANTAL_METINGEN; n++) {
    if (isAangeraakt()) {
      int ruweX = leesRuweX();
      int ruweY = leesRuweY();

      lijstX[geldig] = ruweX;
      lijstY[geldig] = ruweY;
      geldig++;
    }
  }

  if (geldig < MIN_GELDIG) {
    return antwoord;
  }

  int ruwX = mediaan(lijstX, geldig);
  int ruwY = mediaan(lijstY, geldig);

  antwoord.x = naarMm(ruwX, _rawMinX, _rawMaxX, _halfBreedte);
  antwoord.y = naarMm(ruwY, _rawMinY, _rawMaxY, _halfHoogte);
  antwoord.aanwezig = true;

  return antwoord;
}
