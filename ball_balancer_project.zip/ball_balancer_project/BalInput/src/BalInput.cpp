#include "BalInput.h"

static const int AANTAL_METINGEN = 5;
static const int MIN_GELDIG = 3;

static int mediaan(int lijst[], int aantal) {
  for (int i = 0; i < aantal - 1; i++) {
    for (int j = 0; j < aantal - 1 - i; j++) {
      if (lijst[j] > lijst[j + 1]) {
        int tijdelijk = lijst[j];
        lijst[j] = lijst[j + 1];
        lijst[j + 1] = tijdelijk;
      }
    }
  }
  return lijst[aantal / 2];
}

static float naarMm(int ruw, int ruwMin, int ruwMax, float halfGrootte) {
  if (ruwMax == ruwMin) {
    return 0;
  }
  float deel = (float)(ruw - ruwMin) / (float)(ruwMax - ruwMin);
  return (deel * 2.0 - 1.0) * halfGrootte;
}

bool BalInput::begin() {
  return _touch.begin();
}

void BalInput::kalibreer(int rawMinX, int rawMaxX, int rawMinY, int rawMaxY,
                         float halfBreedte, float halfHoogte) {
  _rawMinX = rawMinX;
  _rawMaxX = rawMaxX;
  _rawMinY = rawMinY;
  _rawMaxY = rawMaxY;
  _halfBreedte = halfBreedte;
  _halfHoogte = halfHoogte;
}

void BalInput::zetMinDruk(int minDruk) {
  _minDruk = minDruk;
}

BalPositie BalInput::lees() {
  BalPositie antwoord;
  antwoord.aanwezig = false;
  antwoord.x = 0;
  antwoord.y = 0;

  int lijstX[AANTAL_METINGEN];
  int lijstY[AANTAL_METINGEN];
  int geldig = 0;

  for (int n = 0; n < AANTAL_METINGEN; n++) {
    uint16_t x, y, z1, z2;

    bool aangeraakt = _touch.read_touch(&x, &y, &z1, &z2);

    if (aangeraakt && z1 >= _minDruk) {
      lijstX[geldig] = x;
      lijstY[geldig] = y;
      geldig++;
    }
  }

  if (geldig < MIN_GELDIG) {
    return antwoord;
  }

  int ruwX = mediaan(lijstX, geldig);
  int ruwY = mediaan(lijstY, geldig);

  antwoord.x = naarMm(ruwX, _rawMinX, _rawMaxX, _halfBreedte);
  antwoord.y = naarMm(ruwY, _rawMinY, _rawMaxY, _halfHoogte);
  antwoord.aanwezig = true;
  return antwoord;
}
