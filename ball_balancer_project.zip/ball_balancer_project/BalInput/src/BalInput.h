#ifndef BALINPUT_H
#define BALINPUT_H

#include <Arduino.h>

struct BalPositie {
  bool aanwezig;
  float x;
  float y;
};

class BalInput {
 public:
  bool begin();

  void kalibreer(int rawMinX, int rawMaxX, int rawMinY, int rawMaxY,
                 float halfBreedte, float halfHoogte);

  void zetMinDruk(int minDruk);

  BalPositie lees();

 private:
  static const uint8_t PIN_X_PLUS = A0;
  static const uint8_t PIN_X_MIN  = A1;
  static const uint8_t PIN_Y_PLUS = A2;
  static const uint8_t PIN_Y_MIN  = A3;

  int _rawMinX = 200;
  int _rawMaxX = 3900;
  int _rawMinY = 200;
  int _rawMaxY = 3900;
  float _halfBreedte = 85;
  float _halfHoogte = 64;
  int _minDruk = 100;

  bool isAangeraakt();
  int leesRuweX();
  int leesRuweY();
  void maakPinnenVrij();
};

#endif
