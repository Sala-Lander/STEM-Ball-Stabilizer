#include <Adafruit_TSC2007.h>

Adafruit_TSC2007 touch;

int minX = 4095;
int maxX = 0;
int minY = 4095;
int maxY = 0;

void setup() {
  Serial.begin(115200);

  if (!touch.begin()) {
    Serial.println("Touchscreen-module niet gevonden!");
    Serial.println("Controleer: SDA naar A4, SCL naar A5, voeding en GND.");
    while (true) {
    }
  }
  Serial.println("Module gevonden! Druk nu langs alle randen van het paneel.");
}

void loop() {
  uint16_t x, y, z1, z2;

  if (touch.read_touch(&x, &y, &z1, &z2)) {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;

    Serial.print("x=");     Serial.print(x);
    Serial.print(" y=");    Serial.print(y);
    Serial.print(" druk="); Serial.print(z1);
    Serial.print(" | minX="); Serial.print(minX);
    Serial.print(" maxX=");   Serial.print(maxX);
    Serial.print(" minY=");   Serial.print(minY);
    Serial.print(" maxY=");   Serial.println(maxY);
  }
  else {
    Serial.println("geen aanraking");
  }

  delay(100);
}
